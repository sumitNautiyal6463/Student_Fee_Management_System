namespace FeeManagementSystem.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class First : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.AccountRegister",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Email = c.String(),
                        Password = c.String(),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.AdminRegister",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Email = c.String(),
                        Password = c.String(),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.Branches",
                c => new
                    {
                        BranchId = c.Int(nullable: false, identity: true),
                        BranchName = c.String(),
                    })
                .PrimaryKey(t => t.BranchId);
            
            CreateTable(
                "dbo.FacultyRegister",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Email = c.String(),
                        Password = c.String(),
                        BranchId = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.Branches", t => t.BranchId, cascadeDelete: true)
                .Index(t => t.BranchId);
            
            CreateTable(
                "dbo.FeeBack",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Name = c.String(nullable: false),
                        FatherName = c.String(nullable: false),
                        RollNo = c.Long(nullable: false),
                        Year = c.String(nullable: false),
                        Semester = c.String(nullable: false),
                        BranchId = c.Int(nullable: false),
                        Email = c.String(nullable: false),
                        Phone = c.Long(nullable: false),
                        ExamType = c.String(nullable: false),
                        Subjects = c.Int(nullable: false),
                        AmtPaid = c.Int(nullable: false),
                        BankBranch = c.String(nullable: false),
                        BranchCode = c.Int(nullable: false),
                        JournalNo = c.String(nullable: false),
                        DepositDate = c.DateTime(nullable: false),
                        ChallanName = c.String(),
                        ChallanPath = c.String(),
                        Validate = c.Boolean(nullable: false),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.Branches", t => t.BranchId, cascadeDelete: true)
                .Index(t => t.BranchId);
            
            CreateTable(
                "dbo.FeeSemester",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Name = c.String(nullable: false),
                        FatherName = c.String(nullable: false),
                        RollNo = c.Long(nullable: false),
                        Year = c.String(nullable: false),
                        Semester = c.String(nullable: false),
                        BranchId = c.Int(nullable: false),
                        Phone = c.Long(nullable: false),
                        Email = c.String(nullable: false),
                        TutionFee = c.Int(nullable: false),
                        PDPFee = c.Int(nullable: false),
                        ExamFee = c.Int(nullable: false),
                        SecurityFee = c.Int(nullable: false),
                        Hostel = c.String(nullable: false),
                        HostelFee = c.Int(nullable: false),
                        MessFee = c.Int(nullable: false),
                        OtherFeeName = c.String(),
                        OtherFeePaid = c.Int(nullable: false),
                        BankBranch = c.String(nullable: false),
                        BranchCode = c.Int(nullable: false),
                        JournalNo = c.String(nullable: false),
                        DepositDate = c.DateTime(nullable: false),
                        ChallanName = c.String(),
                        ChallanPath = c.String(),
                        Validate = c.Boolean(nullable: false),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.Branches", t => t.BranchId, cascadeDelete: true)
                .Index(t => t.BranchId);
            
            CreateTable(
                "dbo.StudentRegister",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Name = c.String(nullable: false),
                        FatherName = c.String(nullable: false),
                        RollNo = c.Long(nullable: false),
                        Year = c.String(nullable: false),
                        Semester = c.String(nullable: false),
                        BranchId = c.Int(nullable: false),
                        Phone = c.Long(nullable: false),
                        Email = c.String(nullable: false),
                        Password = c.String(nullable: false, maxLength: 20),
                        ConfirmPassword = c.String(),
                        Activate = c.Boolean(nullable: false),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.Branches", t => t.BranchId, cascadeDelete: true)
                .Index(t => t.BranchId);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.StudentRegister", "BranchId", "dbo.Branches");
            DropForeignKey("dbo.FeeSemester", "BranchId", "dbo.Branches");
            DropForeignKey("dbo.FeeBack", "BranchId", "dbo.Branches");
            DropForeignKey("dbo.FacultyRegister", "BranchId", "dbo.Branches");
            DropIndex("dbo.StudentRegister", new[] { "BranchId" });
            DropIndex("dbo.FeeSemester", new[] { "BranchId" });
            DropIndex("dbo.FeeBack", new[] { "BranchId" });
            DropIndex("dbo.FacultyRegister", new[] { "BranchId" });
            DropTable("dbo.StudentRegister");
            DropTable("dbo.FeeSemester");
            DropTable("dbo.FeeBack");
            DropTable("dbo.FacultyRegister");
            DropTable("dbo.Branches");
            DropTable("dbo.AdminRegister");
            DropTable("dbo.AccountRegister");
        }
    }
}
