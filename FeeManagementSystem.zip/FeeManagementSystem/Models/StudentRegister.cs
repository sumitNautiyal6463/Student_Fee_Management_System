﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace FeeManagementSystem.Models
{
    [Table("StudentRegister")]
    public class StudentRegister
    {
        public int Id { get; set; }

        [Required(ErrorMessage = " * Please Enter Name")]
        [RegularExpression(@"^[a-zA-Z\s]+$", ErrorMessage = " * Please use Characters Only")]
        public string Name { get; set; }

        [Required(ErrorMessage = " * Please Enter Father's Name")]
        [RegularExpression(@"^[a-zA-Z\s]+$", ErrorMessage = " * Please use Characters Only")]
        public string FatherName { get; set; }

        [Required(ErrorMessage = " * Please Enter Roll No")]
        public long RollNo { get; set; }

        [Required(ErrorMessage = " * Please Select Year")]
        public string Year { get; set; }

        [Required(ErrorMessage = " * Please Select Semester")]
        public string Semester { get; set; }

        [Required(ErrorMessage = " * Please Select Branch")]
        public int BranchId { get; set; }

        [Required(ErrorMessage = " * Please Enter Phone No.")]
        public long Phone { get; set; }

        [RegularExpression(".+@.+\\..+", ErrorMessage = " * Please Enter Correct Email")]
        [Required(ErrorMessage = " * Please Enter Email")]
        [Remote("CheckForDuplication", "Home")]
        public string Email { get; set; }

        [Required(ErrorMessage = " * Please Enter Password")]
        [StringLength(20, MinimumLength = 8, ErrorMessage = " * Password must be of Atleast 8 Characters")]
        public string Password { get; set; }

        [System.ComponentModel.DataAnnotations.Compare("Password", ErrorMessage = " * Password Did Not Matched")]
        public string ConfirmPassword { get; set; }

        public Boolean Activate { get; set; }

        public virtual Branch br { get; set; }
    }
}