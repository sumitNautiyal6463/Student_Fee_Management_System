﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace FeeManagementSystem.Models
{
    [Table("FeeSemester")]
    public class FeeSemester
    {
        public int Id { get; set; }

        [Required(ErrorMessage = " * Please Enter Name")]
        [RegularExpression(@"^[a-zA-Z\s]+$", ErrorMessage = " * Please use Characters Only")]
        public string Name { get; set; }

        [Required(ErrorMessage = " * Please Enter Father's Name")]
        [RegularExpression(@"^[a-zA-Z\s]+$", ErrorMessage = " * Please use Characters Only")]
        public string FatherName { get; set; }

        [Required(ErrorMessage = " * Please Enter Roll No")]
        public long RollNo { get; set; }

        [Required(ErrorMessage = " * Please Select Year")]
        public string Year { get; set; }

        [Required(ErrorMessage = " * Please Select Semester")]
        public string Semester { get; set; }

        [Required(ErrorMessage = " * Please Select Branch")]
        public int BranchId { get; set; }

        [Required(ErrorMessage = " * Please Enter Phone No.")]
        public long Phone { get; set; }

        [RegularExpression(".+@.+\\..+", ErrorMessage = " * Please Enter Correct Email")]
        [Required(ErrorMessage = " * Please Enter Email")]
        public string Email { get; set; }

        public int TutionFee { get; set; }
        public int PDPFee { get; set; }
        public int ExamFee { get; set; }
        public int SecurityFee { get; set; }

        [Required(ErrorMessage = " * Please Select Hostel Requirement")]
        public string Hostel { get; set; }
        public int HostelFee { get; set; }
        public int MessFee { get; set; }

        [RegularExpression(@"^[a-zA-Z\s]+$", ErrorMessage = " * Please use Characters Only")]
        public string OtherFeeName { get; set; }
        public int OtherFeePaid { get; set; }

        [Required(ErrorMessage = " * Please Enter Bank Branch")]
        [RegularExpression(@"^[a-zA-Z\s]+$", ErrorMessage = " * Please use Characters Only")]
        public string BankBranch { get; set; }

        [Required(ErrorMessage = " * Please Enter Branch Code")]
        public int BranchCode { get; set; }

        [Required(ErrorMessage = " * Please Enter Journal No.")]
        public string JournalNo { get; set; }

        [Required(ErrorMessage = " * Please Enter Deposit Date")]
        public DateTime DepositDate { get; set; }
        public string ChallanName { get; set; }
        public string ChallanPath { get; set; }
        public Boolean Validate { get; set; }

        public virtual Branch br { get; set; }
    }
}