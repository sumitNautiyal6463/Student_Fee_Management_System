﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;

namespace FeeManagementSystem.Models
{
    public class DataContext : DbContext
    {
        public DataContext() : base("conn")
        {

        }
        public DbSet<StudentRegister> StudReg { get; set; }
        public DbSet<AdminRegister> AdminReg { get; set; }
        public DbSet<AccountRegister> AccountReg { get; set; }
        public DbSet<FacultyRegister> FacultyReg { get; set; }
        public DbSet<FeeSemester> FeesSem { get; set; }
        public DbSet<FeeBack> FeesBack { get; set; }
        public DbSet<Branch> Branches { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<StudentRegister>().HasKey(sr => sr.Id);
            modelBuilder.Entity<StudentRegister>().HasRequired(f => f.br).WithMany().HasForeignKey(c => c.BranchId);
            modelBuilder.Entity<AdminRegister>().HasKey(ar => ar.Id);
            modelBuilder.Entity<AccountRegister>().HasKey(acr => acr.Id);
            modelBuilder.Entity<FacultyRegister>().HasKey(fr => fr.Id);
            modelBuilder.Entity<FacultyRegister>().HasRequired(f => f.br).WithMany().HasForeignKey(c => c.BranchId);
            modelBuilder.Entity<FeeSemester>().HasKey(fs => fs.Id);
            modelBuilder.Entity<FeeSemester>().HasRequired(f => f.br).WithMany().HasForeignKey(c => c.BranchId);
            modelBuilder.Entity<FeeBack>().HasKey(fb => fb.Id);
            modelBuilder.Entity<FeeBack>().HasRequired(f => f.br).WithMany().HasForeignKey(c => c.BranchId);
            modelBuilder.Entity<Branch>().HasKey(b => b.BranchId);
        }
    }
}