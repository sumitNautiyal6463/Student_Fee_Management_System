﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace FeeManagementSystem.Models
{
    [Table("FacultyRegister")]
    public class FacultyRegister
    {
        public int Id { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public int BranchId { get; set; }
        public virtual Branch br { get; set; }
    }
}