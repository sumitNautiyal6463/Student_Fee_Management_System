﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace FeeManagementSystem.Models
{
    public class StudentLogin
    {
        [RegularExpression(".+@.+\\..+", ErrorMessage = " * Please Enter Correct Email")]
        [Required(ErrorMessage = " * Please Enter Email")]
        public string Email { get; set; }

        [Required(ErrorMessage = " * Please Enter Password")]
        [StringLength(20, MinimumLength = 8, ErrorMessage = " * Password must be of Atleast 8 Characters")]
        public string Password { get; set; }
    }
}