﻿using FeeManagementSystem.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.SqlClient;
using System.IO;

namespace FeeManagementSystem.Controllers
{
    public class FeeSubmitController : Controller
    {
        // GET: FeeSubmit
        DataContext db = new DataContext();
        public ActionResult Index()
        {
            if (Session["Email"] != null)
            {
                return View();
            }
            else
            {
                return RedirectToAction("StudentLogin", "Home");
            }
        }

        public ActionResult SemesterFee()
        {
            if (Session["Email"] != null)
            {
                return View();
            }
            else
            {
                return RedirectToAction("StudentLogin", "Home");
            }
        }

        // POST: FeeSubmit/Create
        [HttpPost]
        public ActionResult SemesterFee(FeeSemester collection, HttpPostedFileBase fileupload1)
        {
            try
            {
                // TODO: Add insert logic here
                string filename = string.Empty;
                string filepath = string.Empty;

                filename = fileupload1.FileName;
                string ext = Path.GetExtension(filename);
                if (ext == ".jpg" || ext == ".png" || ext == ".jpeg")
                {
                    DataContext db = new DataContext();
                    filepath = Server.MapPath("~/SemesterFee_Challan/" + collection.RollNo.ToString() + "_");
                    fileupload1.SaveAs(filepath + filename);

                    collection.ChallanName = filename = collection.RollNo.ToString();
                    collection.ChallanPath = "~/SemesterFee_Challan/";

                    db.FeesSem.Add(collection);

                    // db.Entry(model).State = EntityState.Modified;

                    db.SaveChanges();

                    return RedirectToAction("Index");

                }
                else
                {
                    return Content("<script>alert('You can Upload only .jpg ,.jpeg or .png File')</script>");
                }
            }
            catch
            {
                return RedirectToAction("SemesterFee");
            }
        }
        public ActionResult BackFee()
        {
            if (Session["Email"] != null)
            {
                return View();
            }
            else
            {
                return RedirectToAction("StudentLogin", "Home");
            }
        }
        [HttpPost]
        public ActionResult BackFee(FeeBack collection, HttpPostedFileBase fileupload1)
        {
            try
            {
                // TODO: Add insert logic here
                string filename = string.Empty;
                string filepath = string.Empty;

                filename = fileupload1.FileName;
                string ext = Path.GetExtension(filename);
                if (ext == ".jpg" || ext == ".png" || ext == ".jpeg")
                {
                    DataContext db = new DataContext();
                    filepath = Server.MapPath("~/BackFee_Challan/");
                    fileupload1.SaveAs(filepath + filename);

                    collection.ChallanName = filename = collection.RollNo.ToString();
                    collection.ChallanPath = "~/BackFee_Challan/";

                    db.FeesBack.Add(collection);

                    // db.Entry(model).State = EntityState.Modified;

                    db.SaveChanges();

                    return RedirectToAction("Index");
                }
                else
                {
                    return Content("<script>alert('You can Upload only .jpg,.jpeg or .png File')</script>");
                }
            }
            catch
            {
                return RedirectToAction("BackFee");
            }

        }
        public ActionResult Logout()
        {
            Session.Remove("Email");
            Session.RemoveAll();
            return RedirectToAction("Index", "Home");
        }
    }
}
