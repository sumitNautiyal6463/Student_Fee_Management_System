﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using FeeManagementSystem.Models;
using System.Data.SqlClient;

namespace FeeManagementSystem.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        DataContext db = new DataContext();
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Register()
        {
            return View();
        }

        public JsonResult CheckForDuplication(string Email)
        {
            var data = db.StudReg.Where(sr => sr.Email.Equals(Email, StringComparison.CurrentCultureIgnoreCase)).FirstOrDefault();
            if (data != null)
            {
                return Json(" * Email already Exists", JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json(true, JsonRequestBehavior.AllowGet);
            }
        }

        // POST: Register/Create
        [HttpPost]
        public ActionResult Register(StudentRegister collection)
        {
            try
            {
                //TODO: Add insert logic here
                
                db.StudReg.Add(collection);
                db.SaveChanges();
                return RedirectToAction("Register");
            }
            catch
            {
                return RedirectToAction("Register");
            }
        }
        public ActionResult Login()
        {
            return View();
        }
        public ActionResult AdminLogin()
        {
            return View();
        }
        [HttpPost]
        public ActionResult AdminLogin(AdminLogin collection)
        {
            var data = db.AdminReg.SingleOrDefault(a => a.Email.Equals(collection.Email) && a.Password.Equals(collection.Password));
            if (data != null)
            {
                Session["Email"] = data.Email.ToString();
                return RedirectToAction("Index", "Admin");
            }
            else
            {
                return Content("<script>alert('Invalid Email or Password')</script>");
            }
        }

        public ActionResult AccountLogin()
        {
            return View();
        }
        [HttpPost]
        public ActionResult AccountLogin(AccountLogin collection)
        {
            var data = db.AccountReg.SingleOrDefault(a => a.Email.Equals(collection.Email) && a.Password.Equals(collection.Password));
            if (data != null)
            {
                Session["Email"] = data.Email.ToString();
                return RedirectToAction("Index", "AccountDivision");
            }
            else
            {
                return Content("<script>alert('Invalid Email or Password')</script>");
            }
        }

        public ActionResult FacultyLogin()
        {
            return View();
        }
        [HttpPost]
        public ActionResult FacultyLogin(FacultyLogin collection)
        {
            var data = db.FacultyReg.Where(x => x.Email.Equals(collection.Email) && x.Password.Equals(collection.Password)).Select(x => x.BranchId).SingleOrDefault();
            if (data != 0)
            {
                Session["Email"] = data;
                return RedirectToAction("Index", "Faculty");
            }
            else
            {
                return Content("<script>alert('Invalid Email or Password')</script>");
            }
        }

        public ActionResult StudentLogin()
        {
            return View();
        }
        [HttpPost]
        public ActionResult StudentLogin(StudentLogin collection)
        {
            var data = db.StudReg.SingleOrDefault(a => a.Email.Equals(collection.Email) && a.Password.Equals(collection.Password) && a.Activate == true);
            if (data != null)
            {
                Session["Email"] = data.Email.ToString();
                return RedirectToAction("Index", "FeeSubmit");
            }
            else
            {
                return Content("<script>alert('Invalid Email or Password')</script>");
            }
        }
    }
}