﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using FeeManagementSystem.Models;
using System.Data;
using System.Data.Entity.Validation;
using System.Diagnostics;

namespace FeeManagementSystem.Controllers
{
    public class FacultyController : Controller
    {
        DataContext db = new DataContext();
        // GET: Faculty
        public ActionResult Index()
        {
            if (Session["Email"] != null)
            {
                return View();
            }
            else
            {
                return RedirectToAction("FacultyLogin", "Home");
            }
        }
        public ActionResult StudentsList()
        {
            if (Session["Email"] != null)
            {
                int BrId = Convert.ToInt16(Session["Email"]);
                var data = db.StudReg.Where(x => x.BranchId == BrId && x.Activate == false).ToList();
                return View(data);
            }
            else
            {
                return RedirectToAction("FacultyLogin", "Home");
            }
        }
        public ActionResult StudentsDetails(int id)
        {
            if (Session["Email"] != null)
            {
                var data = db.StudReg.Single(x => x.Id == id);
                return View(data);
            }
            else
            {
                return RedirectToAction("FacultyLogin", "Home");
            }
        }
        public ActionResult StudentsVerify(int id)
        {
            if (Session["Email"] != null)
            {
                var data = db.StudReg.Single(x => x.Id == id);
                return View(data);
            }
            else
            {
                return RedirectToAction("FacultyLogin", "Home");
            }
        }
        [HttpPost]
        public ActionResult StudentsVerify(int id, StudentRegister collection)
        {
            try
            {
                var data = db.StudReg.Single(x => x.Id == id);
                if (data != null)
                {
                    data.Activate = collection.Activate;
                    db.SaveChanges();
                }
                return RedirectToAction("StudentsList");
            }
            catch
            {
                return View();
            }
        }
        public ActionResult StudentsReject(int id)
        {
            if (Session["Email"] != null)
            {
                var data = db.StudReg.Single(x => x.Id == id);
                return View(data);
            }
            else
            {
                return RedirectToAction("FacultyLogin", "Home");
            }
        }
        [HttpPost]
        public ActionResult StudentsReject(int id, StudentRegister collection)
        {
            try
            {
                var data = db.StudReg.Single(x => x.Id == id);
                if (data != null)
                {
                    db.StudReg.Remove(data);
                    db.SaveChanges();
                }
                return RedirectToAction("StudentsList");
            }
            catch
            {
                return View();
            }
        }
        public ActionResult SemesterFeeList(string searchString)
        {
            if (Session["Email"] != null)
            {
                int BrId = Convert.ToInt16(Session["Email"]);
               // var data = from a in db.FeesSem select a;
                var data = db.FeesSem.Where(x => x.BranchId == BrId && x.Validate == true);
                //if(!string.IsNullOrEmpty(searchString))
                //{
                //    data = data.Where(s=>s.Name.Contains(searchString) && s.BranchId == BrId && s.Validate == true);
                //}
                //if(!string.IsNullOrEmpty(First))
                //{
                //    data = data.Where(x => x.Name.Trim().Equals(First.Trim()));
                //}

                //var UniqueFirst = from s in data group s by s.Name into newGroup where newGroup.Key != null orderby newGroup.Key select new { First=newGroup.Key};
                //ViewBag.UniqueFirst = UniqueFirst.Select(m => new SelectListItem {Value=m.Name,Text=m.Name })
                //    ViewBag.First = First;
                return View(data.ToList());
            }
            else
            {
                return RedirectToAction("FacultyLogin", "Home");
            }
        }
        public ActionResult SemesterFeeDetails(int id)
        {
            if (Session["Email"] != null)
            {
                var data = db.FeesSem.Single(x => x.Id == id);
                return View(data);
            }
            else
            {
                return RedirectToAction("FacultyLogin", "Home");
            }
        }
        public ActionResult BackFeeList()
        {
            if (Session["Email"] != null)
            {
                int BrId = Convert.ToInt16(Session["Email"]);
                var data = db.FeesBack.Where(x => x.BranchId == BrId && x.Validate == true).ToList();
                return View(data);
            }
            else
            {
                return RedirectToAction("FacultyLogin", "Home");
            }
        }
        public ActionResult BackFeeDetails(int id)
        {
            if (Session["Email"] != null)
            {
                var data = db.FeesBack.Single(x => x.Id == id);
                return View(data);
            }
            else
            {
                return RedirectToAction("FacultyLogin", "Home");
            }
        }
        public ActionResult Logout()
        {
            Session.Remove("Email");
            Session.RemoveAll();
            return RedirectToAction("Index", "Home");
        }
    }
}