﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace FeeManagementSystem.Controllers
{
    public class AboutUsController : Controller
    {
        // GET: AboutUs
        public ActionResult MessageVC()
        {
            return View();
        }
        public ActionResult MessageDirector()
        {
            return View();
        }
        public ActionResult VisionAndMission()
        {
            return View();
        }
    }
}