﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using FeeManagementSystem.Models;
using System.Data.Entity;
using System.Data;

namespace FeeManagementSystem.Controllers
{
    public class AdminController : Controller
    {
        // GET: Admin
        DataContext db = new DataContext();
        public ActionResult Index()
        {
            if (Session["Email"] != null)
            {
                return View();
            }
            else
            {
                return RedirectToAction("AdminLogin", "Home");
            }
        }
        public ActionResult StudentsList()
        {
            if (Session["Email"] != null)
            {
                var data = db.StudReg.Where(x => x.Activate == true).ToList();
                return View(data);
            }
            else
            {
                return RedirectToAction("AdminLogin", "Home");
            }
        }
        public ActionResult StudentsDetails(int id)
        {
            if (Session["Email"] != null)
            {
                var data = db.StudReg.Single(x => x.Id == id);
                return View(data);
            }
            else
            {
                return RedirectToAction("AdminLogin", "Home");
            }
        }
        public ActionResult StudentsDelete(int id)
        {
            if (Session["Email"] != null)
            {
                var data = db.StudReg.Single(x => x.Id == id);
                return View(data);
            }
            else
            {
                return RedirectToAction("AdminLogin", "Home");
            }
        }
        [HttpPost]
        public ActionResult StudentsDelete(int id, StudentRegister collection)
        {
            try
            {
                var data = db.StudReg.Single(x => x.Id == id);
                if (data != null)
                {
                    db.StudReg.Remove(data);
                    db.SaveChanges();
                }
                return RedirectToAction("StudentsList");
            }
            catch
            {
                return View();
            }
        }
        public ActionResult SemesterFeeList()
        {
            if (Session["Email"] != null)
            {
                var data = db.FeesSem.Where(x => x.Validate == true).ToList();
                return View(data);
            }
            else
            {
                return RedirectToAction("AdminLogin", "Home");
            }
        }
        public ActionResult SemesterFeeDetails(int id)
        {
            if (Session["Email"] != null)
            {
                var data = db.FeesSem.Single(x => x.Id == id);
                return View(data);
            }
            else
            {
                return RedirectToAction("AdminLogin", "Home");
            }
        }
        public ActionResult SemesterFeeDelete(int id)
        {
            if (Session["Email"] != null)
            {
                var data = db.FeesSem.Single(x => x.Id == id);
                return View(data);
            }
            else
            {
                return RedirectToAction("AdminLogin", "Home");
            }
        }
        [HttpPost]
        public ActionResult SemesterFeeDelete(int id, FeeSemester collection)
        {
            try
            {
                var data = db.FeesSem.Single(x => x.Id == id);
                if (data != null)
                {
                    db.FeesSem.Remove(data);
                    db.SaveChanges();
                }
                return RedirectToAction("SemesterFeeList");
            }
            catch
            {
                return View();
            }
        }
        public ActionResult BackFeeList()
        {
            if (Session["Email"] != null)
            {
                var data = db.FeesBack.Where(x => x.Validate == true).ToList();
                return View(data);
            }
            else
            {
                return RedirectToAction("AdminLogin", "Home");
            }
        }
        public ActionResult BackFeeDetails(int id)
        {
            if (Session["Email"] != null)
            {
                var data = db.FeesBack.Single(x => x.Id == id);
                return View(data);
            }
            else
            {
                return RedirectToAction("AdminLogin", "Home");
            }
        }
        public ActionResult BackFeeDelete(int id)
        {
            if (Session["Email"] != null)
            {
                var data = db.FeesBack.Single(x => x.Id == id);
                return View(data);
            }
            else
            {
                return RedirectToAction("AdminLogin", "Home");
            }
        }
        [HttpPost]
        public ActionResult BackFeeDelete(int id, FeeSemester collection)
        {
            try
            {
                var data = db.FeesBack.Single(x => x.Id == id);
                if (data != null)
                {
                    db.FeesBack.Remove(data);
                    db.SaveChanges();
                }
                return RedirectToAction("BackFeeList");
            }
            catch
            {
                return View();
            }
        }
        public ActionResult Logout()
        {
            Session.Remove("Email");
            Session.RemoveAll();
            return RedirectToAction("Index", "Home");
        }
    }
}