﻿using FeeManagementSystem.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace FeeManagementSystem.Controllers
{
    public class AccountDivisionController : Controller
    {
        // GET: AccountDivision
        DataContext db = new DataContext();
        public ActionResult Index()
        {
            if (Session["Email"] != null)
            {
                return View();
            }
            else
            {
                return RedirectToAction("AccountLogin", "Home");
            }
        }
        public ActionResult SemesterFeeList()
        {
            if (Session["Email"] != null)
            {
                var data = db.FeesSem.Where(x => x.Validate == false).ToList();
                return View(data);
            }
            else
            {
                return RedirectToAction("AccountLogin", "Home");
            }
        }
        public ActionResult SemesterFeeDetails(int id)
        {
            if (Session["Email"] != null)
            {
                var data = db.FeesSem.Single(x => x.Id == id);
                return View(data);
            }
            else
            {
                return RedirectToAction("AccountLogin", "Home");
            }
        }
        public ActionResult SemesterFeeVerify(int id)
        {
            if (Session["Email"] != null)
            {
                var data = db.FeesSem.Single(x => x.Id == id);
                return View(data);
            }
            else
            {
                return RedirectToAction("AccountLogin", "Home");
            }
        }
        [HttpPost]
        public ActionResult SemesterFeeVerify(int id, FeeSemester collection)
        {
            try
            {
                var data = db.FeesSem.Single(x => x.Id == id);
                if (data != null)
                {
                    data.Validate = collection.Validate;
                    db.SaveChanges();
                }
                return RedirectToAction("SemesterFeeList");
            }
            catch
            {
                return View();
            }
        }
        public ActionResult SemesterFeeReject(int id)
        {
            if (Session["Email"] != null)
            {
                var data = db.FeesSem.Single(x => x.Id == id);
                return View(data);
            }
            else
            {
                return RedirectToAction("AccountLogin", "Home");
            }
        }
        [HttpPost]
        public ActionResult SemesterFeeReject(int id, FeeSemester collection)
        {
            try
            {
                var data = db.FeesSem.Single(x => x.Id == id);
                if (data != null)
                {
                    db.FeesSem.Remove(data);
                    db.SaveChanges();
                }
                return RedirectToAction("SemesterFeeList");
            }
            catch
            {
                return View();
            }
        }
        public ActionResult BackFeeList()
        {
            if (Session["Email"] != null)
            {
                var data = db.FeesBack.Where(x => x.Validate == false).ToList();
                return View(data);
            }
            else
            {
                return RedirectToAction("AccountLogin", "Home");
            }
        }
        public ActionResult BackFeeDetails(int id)
        {
            if (Session["Email"] != null)
            {
                var data = db.FeesBack.Single(x => x.Id == id);
                return View(data);
            }
            else
            {
                return RedirectToAction("AccountLogin", "Home");
            }
        }
        public ActionResult BackFeeVerify(int id)
        {
            if (Session["Email"] != null)
            {
                var data = db.FeesBack.Single(x => x.Id == id);
                return View(data);
            }
            else
            {
                return RedirectToAction("AccountLogin", "Home");
            }
        }
        [HttpPost]
        public ActionResult BackFeeVerify(int id, FeeSemester collection)
        {
            try
            {
                var data = db.FeesBack.Single(x => x.Id == id);
                if (data != null)
                {
                    data.Validate = collection.Validate;
                    db.SaveChanges();
                }
                return RedirectToAction("BackFeeList");
            }
            catch
            {
                return View();
            }
        }
        public ActionResult BackFeeReject(int id)
        {
            if (Session["Email"] != null)
            {
                var data = db.FeesBack.Single(x => x.Id == id);
                return View(data);
            }
            else
            {
                return RedirectToAction("AccountLogin", "Home");
            }
        }
        [HttpPost]
        public ActionResult BackFeeReject(int id, FeeSemester collection)
        {
            try
            {
                var data = db.FeesBack.Single(x => x.Id == id);
                if (data != null)
                {
                    db.FeesBack.Remove(data);
                    db.SaveChanges();
                }
                return RedirectToAction("BackFeeList");
            }
            catch
            {
                return View();
            }
        }
        public ActionResult SemesterAllList()
        {
            if (Session["Email"] != null)
            {
                var data = db.FeesSem.Where(x => x.Validate == true).ToList();
                return View(data);
            }
            else
            {
                return RedirectToAction("AccountLogin", "Home");
            }
        }
        public ActionResult BackAllList()
        {
            if (Session["Email"] != null)
            {
                var data = db.FeesBack.Where(x => x.Validate == true).ToList();
                return View(data);
            }
            else
            {
                return RedirectToAction("AccountLogin", "Home");
            }
        }
        public ActionResult Logout()
        {
            Session.Remove("Email");
            Session.RemoveAll();
            return RedirectToAction("Index", "Home");
        }
    }
}