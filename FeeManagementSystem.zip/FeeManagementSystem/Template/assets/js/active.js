/*
***************************************************************
***************************************************************

Template Name  : WinXpro | Multipurpose Business Template
Author         : Golam
Author URI     : http://golamnabi.com
File           : Active.js

***************************************************************
***************************************************************/

(function ($) {
    "use strict";

var allFunctions = {
        $searchIcon: $(".search-icon"),
        $stickyMenu: $(".header-content-area"),
        $counterUp: $(".single-project-item h2"),
        $masonaryContainer: $(".masonary-container"),
        $testimonialSlider: $(".testomonial-info"),
        $sliderCamera: $('#camera-slide'),
        $sectionScroll: $(".scroll"),
        $brandSlider: $(".brands"),
        $popup: $(".work-popup"),
        $videoPopup: $(".video-icon"),
        $homeSlider: $(".slide-items-wrapper"),
        $blogSlider: $(".blog-slider"),
        $slideMobileMenu: $("#mobile-menu"),
        $colors : $("#demo-colors"),
        customFuctions: {
            searchForm: function () {
                allFunctions.$searchIcon.on("click",
                    function () {
                        $(".search-form").toggleClass('active');
                    });

                $(".main-menu ul.sub-menu ul").parent("li").addClass("siblings");
            },
            sectionScroll: function () {
                allFunctions.$sectionScroll.on('click',
                    function (e) {
                        var $anchor = $(this),
                            headerHeight = 15; // Header height from top
                        $('html, body').stop().animate({
                            scrollTop: $($anchor.attr('href')).offset().top - headerHeight + "px"
                        }, 1200, 'easeInOutExpo');

                        e.preventDefault();
                    }
                );
            },
            sitePreloader: function () {
                var preload = $('.site-preloader-area');
                preload.fadeOut(500, function(){
                    $('.preloader-body').delay(500).fadeOut();
                });
            }
        },
        pluginFunctions: {
            init: function () {
                allFunctions.pluginFunctions.stickyMenu(),
                allFunctions.pluginFunctions.counterUp(),
                allFunctions.pluginFunctions.popup(),
                allFunctions.pluginFunctions.sliderCamera(),
                allFunctions.pluginFunctions.wowAnimation(),
                allFunctions.pluginFunctions.slideMobileMenu(),
                allFunctions.pluginFunctions.googleMap()
            },
            stickyMenu: function () {
                allFunctions.$stickyMenu.sticky({
                    topSpacing: 0,
                    className: 'stickymenu',
                    responsiveWidth: true,
                    zIndex: 999
                });
            },
            counterUp: function () {
                if ($.fn.counterUp) {
                    allFunctions.$counterUp.counterUp({
                        delay: 10,
                        time: 1500
                    });
                }
                
            },
            workMasonary: function () {
                if ($.fn.masonry) {
                    allFunctions.$masonaryContainer.masonry({
                        itemSelector: '.col-md-3'
                    });
                }
            },
            sliderCamera: function () {
                if ($.fn.camera) {
                    allFunctions.$sliderCamera.camera({
                        thumbnails: false,
                        hover: false,
                        fx: 'random',
                        time: 7000,
                        transPeriod: 1500,
                        pagination: false
                    });
                }
            },
            popup: function () {
                if ($.fn.magnificPopup) {
                    allFunctions.$popup.magnificPopup({
                        type: 'image',
                        removalDelay: 300,
                        mainClass: 'mfp-with-zoom',
                        gallery: {
                            enabled: true
                        },
                        zoom: {
                            enabled: true, // By default it's false, so don't forget to enable it

                            duration: 300, // duration of the effect, in milliseconds
                            easing: 'ease-in-out', // CSS transition easing function

                            // The "opener" function should return the element from which popup will be zoomed in
                            // and to which popup will be scaled down
                            // By defailt it looks for an image tag:
                            opener: function (openerElement) {
                                // openerElement is the element on which popup was initialized, in this case its <a> tag
                                // you don't need to add "opener" option if this code matches your needs, it's defailt one.
                                return openerElement.is('a') ? openerElement : openerElement.find('a');
                            }
                        }
                        });

                    allFunctions.$videoPopup.magnificPopup({
                        type: 'iframe',
                        removalDelay: 300,
                        mainClass: 'mfp-fade'
                    });
                }
            },
            wowAnimation: function () {
                new WOW().init();
            },
            slideMobileMenu: function () {
                allFunctions.$slideMobileMenu.mobileMenu({
                    MenuWidth: 250,
                    SlideSpeed: 300,
                    WindowsMaxWidth: 767,
                    PagePush: true,
                    FromLeft: true,
                    Overlay: true,
                    CollapseMenu: true
                });
            },
            googleMap: function () {
                function map_init() {
                    var lat = 23.7788955, // Put your latitude Number here and
                        log = 90.3959633, // Put your longitude Number here
                        mapOptions = {
                            zoom: 14,
                            center: new google.maps.LatLng(lat, log), // New York
                            mapTypeId: google.maps.MapTypeId.ROADMAP,
                            scrollwheel: false,
                            styles: [{
                                "stylers": [{
                                        "hue": "#121212"
}, {
                                        saturation: -100
},
                                    {
                                        gamma: 3
}]
}]
                        },
                        mapElement = document.getElementById('map'),
                        map = new google.maps.Map(mapElement, mapOptions);

                    // Let's also add a marker while we're at it
                    new google.maps.Marker({
                        position: new google.maps.LatLng(lat, log),
                        map: map,
                        icon: 'assets/images/map.png'
                    });
                }
                // When the window has finished loading create our google map below
                google.maps.event.addDomListener(window, 'load', map_init);
            }
        },
        sliderFuncions: {
            init: function () {
                allFunctions.sliderFuncions.testimonialSlider(),
                allFunctions.sliderFuncions.brandSlider(),
                allFunctions.sliderFuncions.homeSlider(),
                allFunctions.sliderFuncions.blogSlider()
            },
            testimonialSlider: function () {
                if($.fn.owlCarousel){
                    allFunctions.$testimonialSlider.owlCarousel({
                        items: 3, // Default is 3
                        loop: true,
                        margin: 30,
                        autoplay: true,
                        autoplayTimeout: 3000, // Default is 5000
                        smartSpeed: 1000, // Default is 250
                        dots: true,
                        dotsEach: true,
                        autoplayHoverPause: true,
                        responsive: {
                            1200: {
                                items: 3
                            },
                            992: {
                                items: 3
                            },
                            768: {
                                items: 2
                            },
                            320: {
                                items: 1
                            }
                        }
                    });
                }
                
            },
            brandSlider: function () {
                if($.fn.owlCarousel){
                    allFunctions.$brandSlider.owlCarousel({
                        items: 5, // Default is 3
                        loop: true,
                        margin: 30,
                        autoplayTimeout: 3000, // Default is 5000
                        smartSpeed: 1000, // Default is 250
                        responsive: {
                            1200: {
                                items: 5
                            },
                            992: {
                                items: 4
                            },
                            768: {
                                items: 3
                            },
                            320: {
                                items: 1
                            },
                            480: {
                                items: 2
                            }
                        }
                    });
                }
            },
            homeSlider: function () {
                if($.fn.owlCarousel){
                    allFunctions.$homeSlider.owlCarousel({
                        items: 1, // Default is 3
                        loop: true,
                        autoplay: true,
                        autoplayTimeout: 7000, // Default is 5000
                        smartSpeed: 1000, // Default is 250
                        dotsEach: true,
                        mouseDrag: false,
                        touchDrag: false,
                        animateIn: 'fadeIn',
                        animateOut: 'fadeOut'
                    });
                }
            },
            blogSlider: function () {
                if($.fn.owlCarousel){
                    allFunctions.$blogSlider.owlCarousel({
                        items: 1, // Default is 3
                        loop: true,
                        autoplay: true,
                        autoplayTimeout: 3000, // Default is 5000
                        dots: false,
                        nav: true,
                        navText: ['<i class="fa fa-angle-left"></i>', '<i class="fa fa-angle-right"></i>'],
                        mouseDrag: false,
                        touchDrag: false,
                        animateIn: 'fadeIn',
                        animateOut: 'fadeOut'
                    });
                }
            }
        },
        ajaxForms: {
            ajaxFormHandle: function (f) {
                f.on("submit", function (e) {
                    e.preventDefault();
                    var a = $(this),
                        b = a.find('msg-box');
                    $.ajax({
                        url: a.attr('action'),
                        type: 'POST',
                        data: a.serialize(),
                        success: function (data) {
                            setTimeout(function () {
                                $(".msg-box").append('<div class="alert alert-msg alert-dismissible" role="alert">' + data + '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><i class="fa fa-times"></i></button></div>');
                                $(".form-control").val('');
                            }, 200 * f);
                        }
                    });
                });
            },
            contact: function () {
                $(".contact-area").each(function () {
                    allFunctions.ajaxForms.ajaxFormHandle($(this).find('form'));
                });
            }
        },
        demoPanel: {
            init: function () {
                $("select").niceSelect(),
                setInterval(allFunctions.demoPanel.demoPanelStyler, 1000),
                allFunctions.demoPanel.demoToggle(),
                allFunctions.demoPanel.colorToggle(),
                allFunctions.demoPanel.colorChange();
            },
            demoPanelStyler: function () {
                var headerTop = $('.headerTop'),
                    headerTop = $('.headerTop select').val(),
                    header = $('.header-area'),
                    headerTopWrap = $('.header-top-area');

                if (headerTop == "enable") {
                    header.find(headerTopWrap).slideDown();
                } 
                else {
                    header.find(headerTopWrap).slideUp();
                }
            },
            demoToggle: function () {
                var panelIcon = $(".demo-panel-icon");
                panelIcon.on('click', function (e) {
                    e.preventDefault();
                    $(".deme-panel").toggleClass('active');
                });
            },
            colorToggle: function () {
                $("ul.colors").each(function () {
                    var color = $('ul.colors li a');
                    color.on("click", function (e) {
                        e.preventDefault();
                        $(this).parents('ul.colors').find('a').removeClass('active');
                        $(this).addClass('active');
                    });
                });  
            },
            colorChange: function () {
                var a = $(".colorOne" ),
                    b = $(".colorTwo" ),
                    c = $(".colorThree" ),
                    d = $(".colorFour" ),
                    e = $(".colorFive" ),
                    f = $(".colorSix" ),
                    g = $(".colorSeven" ),
                    h = $(".colorEight" );
                a.on("click", function(){
                    allFunctions.$colors.attr("href", "assets/css/colors/color-light-yellow.css" );
                    $('.logo').find('a').html('<img src="assets/images/winXpro-logo.png" alt="">');
                    $('.footer-logo').find('a').html('<img src="assets/images/footer-logo.png" alt="">');
                    return false;
                });

                b.on("click", function(){
                    allFunctions.$colors.attr("href", "assets/css/colors/color-blue.css" );
                    $('.logo').find('a').html('<img src="assets/images/winXpro-logo-2.png" alt="">');
                    $('.footer-logo').find('a').html('<img src="assets/images/footer-logo-2.png" alt="">');
                    return false;
                });
                c.on("click", function(){
                    allFunctions.$colors.attr("href", "assets/css/colors/color-teal.css" );
                    $('.logo').find('a').html('<img src="assets/images/winXpro-logo-3.png" alt="">');
                    $('.footer-logo').find('a').html('<img src="assets/images/footer-logo-3.png" alt="">');
                    return false;
                });
                d.on("click", function(){
                    allFunctions.$colors.attr("href", "assets/css/colors/color-deep-orange.css" );
                    $('.logo').find('a').html('<img src="assets/images/winXpro-logo-4.png" alt="">');
                    $('.footer-logo').find('a').html('<img src="assets/images/footer-logo-4.png" alt="">');
                    return false;
                });
                e.on("click", function(){
                    allFunctions.$colors.attr("href", "assets/css/colors/color-green.css" );
                    $('.logo').find('a').html('<img src="assets/images/winXpro-logo-5.png" alt="">');
                    $('.footer-logo').find('a').html('<img src="assets/images/footer-logo-5.png" alt="">');
                    return false;
                });
                f.on("click", function(){
                    allFunctions.$colors.attr("href", "assets/css/colors/color-light-orange.css" );
                    $('.logo').find('a').html('<img src="assets/images/winXpro-logo-6.png" alt="">');
                    $('.footer-logo').find('a').html('<img src="assets/images/footer-logo-6.png" alt="">');
                    return false;
                });
                g.on("click", function(){
                    allFunctions.$colors.attr("href", "assets/css/colors/color-light-green.css" );
                    $('.logo').find('a').html('<img src="assets/images/winXpro-logo-7.png" alt="">');
                    $('.footer-logo').find('a').html('<img src="assets/images/footer-logo-7.png" alt="">');
                    return false;
                });
                h.on("click", function(){
                    allFunctions.$colors.attr("href", "assets/css/colors/color-pink.css" );
                    $('.logo').find('a').html('<img src="assets/images/winXpro-logo-8.png" alt="">');
                    $('.footer-logo').find('a').html('<img src="assets/images/footer-logo-8.png" alt="">');
                    return false;
                });
            }
        }
    }

    $(window).on('load', function () {
        allFunctions.pluginFunctions.workMasonary();
        allFunctions.customFuctions.sitePreloader();
    });
    
    $(document).ready(function () {
        allFunctions.customFuctions.searchForm();
        allFunctions.customFuctions.sectionScroll();
        allFunctions.pluginFunctions.init();
        allFunctions.sliderFuncions.init();
        allFunctions.ajaxForms.contact();
        allFunctions.demoPanel.init();
    });

})(jQuery);